import globals from 'globals';
import tseslint from 'typescript-eslint';

/** @type {import('eslint').Linter.Config[]} */
export default [
  {
    // Apply to TypeScript files in the src directory
    files: ['src/**/*.ts'],
    languageOptions: {
      globals: {
        ...globals.node, // Use Node.js globals for Express.js
      },
      ecmaVersion: 'latest', // Use the latest ECMAScript version
      sourceType: 'module', // Use 'module' for ES modules
    },
    rules: {
      'no-console': 'warn', // Warn if console.log is used
      'no-unused-vars': 'warn', // Warn about unused variables
      '@typescript-eslint/no-require-imports': 'error', // Enforce ES modules in TypeScript
    },
  },

  ...tseslint.configs.recommended, // TypeScript recommended rules
];
